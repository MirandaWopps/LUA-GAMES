-- MUDAR meu id!!!!
local meuid = "ADOLF"
local m = mqtt.Client("clientid " .. meuid, 120)


-- botoes
local sw1 = 5  --1
local sw2 = 4 -- 4

-- botoes anexados, mas leitura nao e aqui
gpio.mode(sw1, gpio.INT, gpio.PULLUP)
gpio.mode(sw2, gpio.INT, gpio.PULLUP)


function publica(c)
  c:publish("inf1350-a","alo de " .. meuid,0,0,
            function(client) print("mandou! HORA DO EXTERMINIO") end)
end

function publicaBotao(c)
--[[  c:publish("inf1350-a","alo de " .. meuid,0,0, 
            function(client) print("b1") end)]]

      c:publish("paraloveA16","alo de " .. meuid,0,0,
            function(client) print("b1") end)  
end



function novaInscricao (c)
  local msgsrec = 0
  function novamsg (c, t, m)
    print ("mensagem SOLUÃ‡ÃƒO FINAL BRASILSIL ".. msgsrec .. ", topico: ".. t .. ", dados: " .. m)
    msgsrec = msgsrec + 1
  end
  gpio.trig(sw1, "down", function () print("-> sw1") c:publish("paraloveA16","0",2,0) end)
  gpio.trig(sw2, "down", function () print("-> sw2") c:publish("paraloveA16","10",2,0) end)
  print("==> NovaInscrição")
  c:on("message", novamsg)
end

function conectado (client)
  --publica(client)
  client:subscribe("paranodeA16", 0, novaInscricao)
end 

m:connect("139.82.100.100", 7981, false, 
             conectado,
             function(client, reason) print("failed reason: "..reason) end)
         

