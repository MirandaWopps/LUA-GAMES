local vEnemy = {} -- Vetor com inimigos
local score = 0 -- Pontos

local mqtt = require("mqtt_library") -- importa biblioteca MQTT para o zerobrane
-- Lugar de desenho do carro
local x = 160
local y = 540

-- Move carro para direita.
function goRight()
    x = x +50
end

-- Move carro para esquerda.
function goLeft()
    x = x -50
end

-- Entidade com muito encapsulamento e corroutine.
-- Parâmetros: a posição do inimigo e a posição do carro.
function enemy(xPos, yPos, xCar, yCar)
  local x = xPos
  local y = yPos

  -- funcao local dr está com corroutine e irá desenhar o inimigo.
  local dr = function()  
    while true do -- Loop para coroutine existir.
      love.graphics.setColor(1, 1, 1)  -- nao necessaria para desenhar imagens.
      --enemyImage = love.graphics.newImage("enemy.png")
      --love.graphics.draw(enemyImage, x, y)   -- Se por x, y no final ele desenha so 1            
      love.graphics.circle( "fill", x, y, 50 )
      coroutine.yield() -- para corountine.
    end
  end
    
    
  -- Funcao local atualiza posição e pode autoriza "matar" inimigo através do status que é retornado..
  local updt = function(dt) -- dt é o param que sempre atualiza com o tempo
      while true do  -- classico para fazer coroutine
          y = y+ (50*dt)   -- move verticalmente
         

         
         dt = coroutine.yield() -- para coroutine salvando argumento passado nessa função 
      end
  end  
    
  
  -- funcao verifica um crash
  local crashedByCar = function (xCar,yCar) -- Pega informacao atual do carro
      while true do -- Necessário para coroutine
          -- parte tocando o carro
          status = false  
          if (y>=540) and (x >= xCar and x<= xCar + 160) then -- Verifica encosto no carro
              status = true;    -- status true indica permissao para remocao do vetor vEnemy
              score = score  +1 -- aumenta score, isto e, potuacao.
          end
      
          xCar,yCar = coroutine.yield (status) -- Passa variável status como retorno
      end 
  end
  
    
    
   return { -- como as funcoes locais serão chamadas fora do encapsulamento
        crashed = coroutine.wrap(crashedByCar), -- recebe retorno vindo da crashedByCar
        
        draw = coroutine.wrap(dr), -- draw está portando a funcao local dr
        
        update = coroutine.wrap(updt), -- update possui execucao da funcao updt local
        
    }
  
end

-- Funcao callback da conexao com cliente lá na load(). Se conteúdo da mensagem for
--   igual a 10, então, vai executar funcao para atualizar o X e idem goRight se mensagem for
--   diferente de 10.
--   O print é por motivos de debug e apenas informa o topico e a mensagem recebida.
function mqttcb(topic, message)
  print("Received: " .. topic .. ": " .. message)
  local m = message     
  if m=="10" then
    goLeft();
  else
    goRight();
  end
end

-- Carrega antes de draw
function love.load ()
  love.window.setMode( 800, 860) -- Tela tem 800 de largura e 860 de largura
  car = love.graphics.newImage("car2.png")
  love.graphics.setBackgroundColor(0,0,0) -- diz ser 

  -- Conexao com cliente no endereço ip 139.82.100.100 porta 7981 e mqttcb e a func call back
  mqtt_client = mqtt.client.create("139.82.100.100", 7981, mqttcb)
  mqtt_client:connect("cliente love A16") -- Nomeia o "clienteID" na rede.
  
  -- Parte para escutar o VC comeÃ§ou no subscribe.
  mqtt_client:subscribe({"paraloveA16"},0,move) -- Escreve no topico paraloveA16, qos 0, executa
                                                 --   func move levando como argumento cliente.
                                                 -- A func move nao existe mais, mas tirar essa
                                                 -- linha compromete o funcionamento do codigo.
                                                 
  -- Criacao de enemys, isto é, insercao deles no vetor vEnemy
  table.insert(vEnemy, enemy(300,-50,x,y) )  
  table.insert(vEnemy, enemy(500,-200,x,y) )  
  table.insert(vEnemy, enemy(100,-350,x,y) )  
  table.insert(vEnemy, enemy(200,-500,x,y) )  
  table.insert(vEnemy, enemy(400,-750,x,y) )  
  
end

-- Funcao update do LOVE2D: possui atualização de infos da rede, remoção e movimento de inimigos e pontuação.
function love.update(dt)
  -- tem que chamar o handler aqui! Ele mantém as informações de rede agindo nesse código.
  mqtt_client:handler()
  
  -- Update e cuida de remover
  for i, enemy in ipairs(vEnemy) do
      -- Chama funcao da entidade enemy que movimenta e em caso de abate aummenta score.
      -- Tambem passa dt atual: numero crescente desde que o jogo comecou.
      vEnemy[i].update(dt)
        
      -- Remocao
      status = vEnemy[i].crashed(x,y) -- True or False se bater
      if status then      
          print("Remove") -- printa remove para fins de debug
          table.remove(vEnemy, i) -- Remove o inimigo da lista
      end
  end      
  
end

-- Funcao desenhara no love
function love.draw ()
  -- Desenha os inimigos no vetor vEnemy
  for i, enemy in ipairs(vEnemy) do
    enemy.draw() -- desenha inimigo atraves da ativacao da funcao dentro do acoplamento
  end      

  love.graphics.setColor(1,1,1) -- pinta de branco o inimigo
  love.graphics.draw( car, x, y) -- Desenha carro
  love.graphics.print(score, 50 , 50) -- exibe pontuacao

end

-- Evita que processo continue, precisando abater via gerenciador de tarefas.
function love.quit()
  os.exit()
end